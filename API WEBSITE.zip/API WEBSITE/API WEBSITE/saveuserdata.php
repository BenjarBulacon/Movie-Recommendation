
<?php

$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "qwerwebsite"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $email = $_POST["gmail"];
    $password = $_POST["password"];

   
    $sql = "INSERT INTO users (Gmail, password) VALUES ('$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "User data saved successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


$conn->close();
?>